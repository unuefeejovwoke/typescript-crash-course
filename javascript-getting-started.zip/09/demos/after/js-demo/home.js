
const containers = 
    document.getElementsByClassName('container');
containers[0].classList.add('d-none');
console.log(containers);